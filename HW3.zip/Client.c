#include "Client.h"

/*creates new list of clients*/
Client* createClientList(Client* clientList, int size){}

/*adds new client to the clients list[index]. return 1 if succeed, 0 if failed*/
int addNewClient(){}

/*help function to call in addNewClient*/
int appendClientToList(Client client){}

