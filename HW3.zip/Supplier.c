#include "Supplier.h"

/*creates new list of suppliers*/
Supplier * createSupplierList(Supplier* supplierList, int size){}

/*adds new supplier to the suppliers list[index]. return 1 if succeed, 0 if failed*/
int addNewSupplier(){}

/*help function to call in addNewSupplier*/
int appendSupplierToList(Supplier supplier){}

