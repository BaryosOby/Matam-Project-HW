#include "Car.h"

/*creates new list of cars*/
Car* createCarList(Car* carList, int size){}

/*adds new car to the cars list[index]. return 1 if succeed, 0 if failed*/
int addNewCar(){}

/*help function to call in addNewCar*/
int appendCarToList(Car car){}
