#ifndef CAR_H
#define CAR_H

typedef struct{
    char licenseNum[8];
    char chassisNum[6];
    char manufacturer[11];
    char model[11];
    char color[8];
    int manufactorYear;
    int onRoadSince;
    double priceFromSupplier;
    double currentPrice;
    int velocity;

}Car;

/*creates new list of cars*/
Car* createCarList(Car* carList, int size);

/*adds new car to the cars list[index]. return 1 if succeed, 0 if failed*/
int addNewCar();

/*help function to call in addNewCar*/
int appendCarToList(Car car);

#endif //CAR_H
