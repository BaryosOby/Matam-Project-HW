#ifndef CLIENT_H
#define CLIENT_H

typedef struct{

    char name[21];
    char surname[21];
    char id[10];
    char rentedCarLicense[8];
    char rentDate[11];
    char rentHour[6];
    float PriceForDay;
}Client;

/*creates new list of clients*/
Client* createClientList(Client* clientList, int size);

/*adds new client to the clients list[index]. return 1 if succeed, 0 if failed*/
int addNewClient();

/*help function to call in addNewClient*/
int appendClientToList(Client client);


#endif //CLIENT_H
