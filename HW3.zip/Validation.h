#ifndef VALIDATION_H
#define VALIDATION_H

/*checks if given string is in the right size*/
int isStrValid(char* str, int size);

/*checks if given integer is in the right size*/
int isIntValid(int number, int size);

/*checks if given double is in the right size*/
int isDoubleValid(double number, int size);

/*checks if an array is in its full capacity*/
int isArrayFull(void* ptr);

#endif //VALIDATION_H
